/*
 * um: not enough room in SDU list
 */
TIME, 1,
    ENB_UM, 10, 10, 35, 5,
    UE_UM, 100, 100, 35, 5,
    ENB_SDU, 0, 20,
    ENB_BUFFER_STATUS,
TIME, -1
